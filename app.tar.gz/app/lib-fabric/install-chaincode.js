/**
 * Copyright 2017 IBM All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
'use strict';
var util = require('util');
var helper = require('./helper.js');
var logger = helper.getLogger('install-chaincode');


// we must pass here admin user
function installChaincode(peers, chaincodeName, chaincodePath, chaincodeVersion, username, org) {
  logger.debug('\n============ Install chaincode on organizations ============\n');
  helper.setupChaincodeDeploy();
  return helper.getClientForOrg(username, org)
    .then(client=>{
			var request = {
				targets: helper.newPeers(peers),
				chaincodePath: chaincodePath,
				chaincodeId: chaincodeName,
				chaincodeVersion: chaincodeVersion
			};
			return client.installChaincode(request);
		}, (err) => {
			logger.error('Failed to enroll user \'' + username + '\'. ' + err);
			throw new Error('Failed to enroll user \'' + username + '\'. ' + err);
		}).then((results) => {
			var proposalResponses = results[0];
			// var proposal = results[1];
			var all_good = true;
			for (var i in proposalResponses) { // jshint ignore:line
				let one_good = false;
				if (proposalResponses && proposalResponses[0].response &&
					proposalResponses[0].response.status === 200) {
					one_good = true;
					logger.info('install proposal was good');
				} else {
					logger.error('install proposal was bad');
				}
				all_good = all_good & one_good; // jshint ignore:line
			}
			if (all_good) {
				logger.info(util.format('Successfully sent install Proposal and received ProposalResponse: Status - %s', proposalResponses[0].response.status));
				logger.debug('\nSuccessfully Installed chaincode on organization ' + org + '\n');
				return 'Successfully Installed chaincode on organization ' + org;
			} else {
				logger.error('Failed to send install Proposal or receive valid response. Response null or status is not 200. exiting...');
				throw new Error('Failed to send install Proposal or receive valid response. Response null or status is not 200');
			}
		}, (err) => {
			logger.error('Failed to send install proposal due to error: ' + err.stack ? err.stack : err);
			throw new Error('Failed to send install proposal due to error: ' + err.stack ? err.stack : err);
		});
}

exports.installChaincode = installChaincode;
